<!doctype html>
<html>
<head>
    <title>
        Variables
    </title>
</head>
<body>

    <h1>Exercise 1: Create and Display Variables</h1>

    <h2>String Variable:</h2>

    <h2>Integer Variable:</h2>

    <h2>Print Variable from Function:</h2>

    <h2>Static Variable:</h2>

    <h2>Global Variable:</h2>

    <h2>Super Global Variable:</h2>

    <h2>Variables of Variables:</h2>

</body>
</html>

