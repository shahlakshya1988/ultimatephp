<?php

    //https://www.php.net/manual/en/reserved.variables.php
    @$val = 1/0;
    echo $php_errormsg;

