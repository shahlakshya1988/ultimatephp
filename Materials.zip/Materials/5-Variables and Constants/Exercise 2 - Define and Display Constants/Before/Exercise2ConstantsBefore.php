<!doctype html>
<html>
<head>
    <title>
        Constants
    </title>
</head>
<body>

    <h1>Exercise 1: Define and Display Constants</h1>

    <h2>String Constant:</h2>

    <h2>Integer Constant:</h2>

    <h2>Print Constant from Function:</h2>

    <h2>Display Magic Constant:</h2>

</body>
</html>

