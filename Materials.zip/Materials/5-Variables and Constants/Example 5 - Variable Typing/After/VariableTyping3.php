<?php

	//Sample 1
	$length = 10;
	$breath = 20;
	$area = $length * $breath;
	echo "Area: $area";

	//Sample 2
	$length = "10";
	$breath = 20;
	$area = $length * $breath;
	echo "Area: $area";


	//Sample 3
	$length = "1";
	$breath = "a";
	$area = $length * $breath;
	echo "Area: $area";

