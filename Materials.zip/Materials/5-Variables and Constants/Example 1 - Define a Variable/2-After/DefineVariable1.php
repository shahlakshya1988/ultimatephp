<!doctype html>
<html>
<head>
    <title>
        Variables and Constants
    </title>
</head>
<body>

	<!-- Sample 1 -->
	<?php
		
		//Define a Variable
		$aboutme = "I am Srini and I love PHP Programming!";
		echo "<h1>About Me:</h1>";
		echo $aboutme; //Printing the Variable

	?>

</body>
</html>

