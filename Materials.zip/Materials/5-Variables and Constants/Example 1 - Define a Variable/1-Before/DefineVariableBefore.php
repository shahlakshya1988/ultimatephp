<!doctype html>
<html>
<head>
    <title>
        Variables and Constants
    </title>
</head>
<body>


</body>
</html>

