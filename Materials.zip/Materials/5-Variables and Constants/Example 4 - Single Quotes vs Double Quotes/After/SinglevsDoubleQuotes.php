<?php
    $message = "This is a PHP Language";

    echo "Printing the message Variable: $message";
    echo 'Printing the message Variable: $message';

    echo 'PHP prints this message faster!';

    $message2 = "I love PHP Programming!";
    echo "$message - $message2";
    echo "$message - " . '$message2';

