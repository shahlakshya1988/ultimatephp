<?= "Welcome to PHP!" ?>
<?php
    echo 'Hello World!';
    print "This is printed from the Console.";
