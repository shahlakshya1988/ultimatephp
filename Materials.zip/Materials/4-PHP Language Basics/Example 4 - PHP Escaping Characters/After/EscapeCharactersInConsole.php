
<?php
/*
\n - New Line
\r - Carriage Return
\t - Tab
\$ - Dollar Sign
\" - Double Quotes
\' - Single Quotes
\\ - Single Backslash
 */

    echo 'This isn\'t the way we wanted to printed';

    echo '\nThis is printed on new line\n';

    echo '\nWe have tab \t\t here.\n';

    echo " This is a \"Special\" character inside the PHP";

