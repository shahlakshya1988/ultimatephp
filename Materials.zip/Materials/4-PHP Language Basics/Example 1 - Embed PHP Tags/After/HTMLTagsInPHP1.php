<!doctype html>
<html>
<head>
    <title>
        PHP and HTML
    </title>
</head>
<body>

    <h1>Embed PHP in HTML</h1>
    <!-- Sample 1 -->
    <?php echo "Hello World"; ?>

</body>
</html>