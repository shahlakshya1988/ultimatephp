<?php

    include "NamespacesConstant.php";

    echo MyNamespaceName\FILE_NAME;
