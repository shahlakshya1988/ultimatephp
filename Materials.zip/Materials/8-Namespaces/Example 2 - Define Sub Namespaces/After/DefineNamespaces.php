<?php

    //Include the namespace file
    include "NamespaceConstants2-1.php";
    include "NamespaceConstants2-2.php";

    //Access the Namespace.
    echo SubNamespaces\Sub1\FILE_NAME;
    echo SubNamespaces\Sub2\FILE_NAME;