<?php



    //namespace is the keyword to define namespace.
    namespace SubNamespaces\Sub1;

    //Constants are allowed in namespaces.
    const FILE_NAME = "Sub1\NamespaceConstants2-1.php" . PHP_EOL;