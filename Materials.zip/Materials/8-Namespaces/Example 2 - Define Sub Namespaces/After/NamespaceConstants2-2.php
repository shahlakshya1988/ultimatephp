<?php


    //namespace is the keyword to define namespace.
    namespace SubNamespaces\Sub2;

    //Constants are allowed in namespaces.
    const FILE_NAME = "Sub2\NamespaceConstants2-2.php" . PHP_EOL;