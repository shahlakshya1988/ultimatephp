<?php
    namespace StudentConstants;

    const TOTAL_SUBJECTS = 7;
    const TOTAL_MARKS = 700;
    const PASSING_MARKS = 200;
