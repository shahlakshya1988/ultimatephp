<?php

    include "MyNamespace.php";

    echo "Total Marks: " . StudentConstants\TOTAL_MARKS . PHP_EOL;
    echo "Passing Marks: " . StudentConstants\PASSING_MARKS . PHP_EOL;