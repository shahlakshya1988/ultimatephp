
<?php

    echo 'My Name is Srini!';

    print 'My Favourite thing is to play online games.';

?>

<?= "My Hobbies is to watching movies." ?>
