


<?= "PHP is Interesting!" //Comments Here are fine ?>

<?php

    echo "Welcome to PHP!"; //This is Echo Method

?>

