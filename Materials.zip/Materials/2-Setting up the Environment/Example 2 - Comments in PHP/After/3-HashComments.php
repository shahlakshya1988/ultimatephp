


<?= "PHP is Interesting!" #Comments Here are fine ?>

<?php

    echo "Welcome to PHP!"; #This is Echo Method

    #print method is used to display any text on the web page.
    print "Excited to learn this new Language." #This is Print statement.

?>

