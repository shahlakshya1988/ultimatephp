

<?php

    echo "Welcome to PHP!";
    print "Excited to learn this new Language."

?>

<?= "PHP is Interesting!" ?>
<?= 'PHP is Interesting!'; ?>


