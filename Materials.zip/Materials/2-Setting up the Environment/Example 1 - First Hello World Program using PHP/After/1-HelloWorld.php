<?php

    echo "Hello World!";
    echo 'Hello World!';

?>

