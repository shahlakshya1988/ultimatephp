<?php

    print "Hello World!";
    print 'Hello World!';

?>

