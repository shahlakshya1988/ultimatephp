<?php

    $value = 1/0; //This line is a error and will not proceed further.
    echo $php_errormsg;

