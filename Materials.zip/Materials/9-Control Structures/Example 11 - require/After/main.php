<?php
    include "header.php";
?>


<body>

<?php
    include "menu.php";
    require "submenu.php";
?>

<h1>Exercise 2: How to Use the Include Function</h1>


<?php
    include "footer.htm";
?>
