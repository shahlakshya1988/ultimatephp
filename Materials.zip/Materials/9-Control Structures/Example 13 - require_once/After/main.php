<?php
    include "header.php";
?>


<body>

<?php
    require "menu.php";

    //This is recommended to use always if want to embed anything once and file must exists.
    require_once "menu.php";
?>

<h1>Exercise 2: How to Use the Require Once Function</h1>


<?php
    include "footer.htm";
?>
