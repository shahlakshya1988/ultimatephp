<?php
    include "header.php";
?>


<body>

<?php
    include "menu.php";
    include_once "menu.php";
    include "menu.php";
    include_once "menu.php";
?>

<h1>Exercise 2: How to Use the Include Once Function</h1>


<?php
    include "footer.htm";
?>
