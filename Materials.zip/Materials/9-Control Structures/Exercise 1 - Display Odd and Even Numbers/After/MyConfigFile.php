<?php
    namespace MyConfigFile;
    const MAX_NUMBERS = 10;

?>