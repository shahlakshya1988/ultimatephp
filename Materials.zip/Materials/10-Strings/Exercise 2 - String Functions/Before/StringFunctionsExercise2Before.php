<!doctype html>
<html>
<head>
    <title>
        Strings
    </title>
</head>
<body>

<h1>Exercise 2: String Functions</h1>

<h2>Word Wrap the Long String</h2>

<h2>Find and Replace the word in upper case</h2>

<h2>Count number of words</h2>

<h2>Shuffle the Strings</h2>


</body>
</html>

