<?php

    $name = "John, Smith";
    echo strlen($name) . PHP_EOL;

    //echo strlen($name1);

    $name2 = "";
    echo strlen($name2) . PHP_EOL;

    $name2 = null;
    echo strlen($name2) . PHP_EOL;
